#include "Header.h"

void createDots(Vector2* redPos, dot dots[])
{
	for (int i = 0; i < dotCount; i++)
	{
		float xdilation = static_cast <float> (rand()) / static_cast <float> (RAND_MAX);
		float ydilation = static_cast <float> (rand()) / static_cast <float> (RAND_MAX);
		int x = GetScreenWidth() * xdilation;
		int y = GetScreenHeight() * ydilation;
		dot circle;
		circle.x = x;
		circle.y = y;
		if (i == 0)
		{
			circle.color = RED;
			*redPos = { (float)x, (float)y };
		}
		else
		{
			circle.color = BLACK;
		}
		dots[i] = circle;
	}
}

void drawDots(dot* dots, float radius)
{
	for (dot* d = dots; d != dots+dotCount; d++)
		DrawCircle((*d).x, (*d).y, radius, (*d).color);
}