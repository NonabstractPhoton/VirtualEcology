#pragma once
#include "raylib.h"
#include "raymath.h"
#include <iostream>

struct dot {
	int x; int y; Color color;		
};

const int dotCount = 10;

void createDots(Vector2* redPos, dot dots[]);
void drawDots(dot* dots, float radius);