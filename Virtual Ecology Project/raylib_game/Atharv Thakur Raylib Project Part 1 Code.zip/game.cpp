#include "Header.h"
#include "Player.cpp"

using namespace std;

int main(void)
{
    const int xDim = 800, yDim = 450;
    const float dotRadius = 5.0f;
    InitWindow(xDim, yDim, "raylib [core] example - basic window");
    SetTargetFPS(60);
    Player player("Player.png");
    dot dots[dotCount];
    Vector2 target = Vector2One();

    createDots(&target, dots);

    while (!WindowShouldClose())
    {
        BeginDrawing();
        ClearBackground(WHITE);

        drawDots(dots, dotRadius);
        player.update(target);

        if (GetTime() - (double)((int)GetTime()) < GetFrameTime() && ((int)GetTime()) % 5 == 0) // Start of the (5n)th second
        {
            createDots(&target, dots);
            player.resetTurnProgress();
        }

        EndDrawing();
    }

    CloseWindow();

    return 0;
}